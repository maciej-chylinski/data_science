class Params(object):
    data_file = "AirQualityUCI.csv"
    missing_value = -200.0
    correlation_ratio = 0.7

